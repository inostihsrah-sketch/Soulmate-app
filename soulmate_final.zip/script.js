// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyAWLcW7klZXe0LcKDaRdyPC8Hcxui_m0JI",
  authDomain: "soulmate-f676e.firebaseapp.com",
  projectId: "soulmate-f676e",
  storageBucket: "soulmate-f676e.firebasestorage.app",
  messagingSenderId: "677028886809",
  appId: "1:677028886809:web:ad770da70d28666fe8ed88",
  measurementId: "G-FYE4RKCY1C"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// Auth
function signUp() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  auth.createUserWithEmailAndPassword(email, password).then(() => {
    alert("Signup successful!");
  }).catch(alert);
}

function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  auth.signInWithEmailAndPassword(email, password).then(() => {
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("profile-section").classList.remove("hidden");
  }).catch(alert);
}

// Save profile
function saveProfile() {
  const user = auth.currentUser;
  const name = document.getElementById("name").value;
  const age = document.getElementById("age").value;
  const gender = document.getElementById("gender").value;
  const file = document.getElementById("profilePic").files[0];

  if (!user) return alert("Login first");

  const ref = storage.ref("profiles/" + user.uid + ".jpg");
  ref.put(file).then(() => {
    ref.getDownloadURL().then(url => {
      db.collection("users").doc(user.uid).set({ name, age, gender, photo: url });
      alert("Profile saved!");
      document.getElementById("profile-section").classList.add("hidden");
      document.getElementById("discover-section").classList.remove("hidden");
    });
  });
}

// Discover profiles
db.collection("users").onSnapshot(snapshot => {
  const profiles = document.getElementById("profiles");
  profiles.innerHTML = "";
  snapshot.forEach(doc => {
    const u = doc.data();
    const div = document.createElement("div");
    div.className = "profile-card";
    div.innerHTML = `<img src="${u.photo}" alt=""><h3>${u.name}, ${u.age}</h3><p>${u.gender}</p><button onclick="likeUser('${doc.id}')">Like ❤️</button>`;
    profiles.appendChild(div);
  });
});

// Likes
function likeUser(uid) {
  const user = auth.currentUser;
  if (!user) return alert("Login first");
  db.collection("likes").add({ from: user.uid, to: uid });
  alert("You liked this profile ❤️");
}

// Chat
function sendMessage() {
  const msg = document.getElementById("chatInput").value;
  const user = auth.currentUser;
  if (!user) return;
  db.collection("messages").add({ uid: user.uid, text: msg, time: Date.now() });
  document.getElementById("chatInput").value = "";
}

db.collection("messages").orderBy("time").onSnapshot(snapshot => {
  const messagesDiv = document.getElementById("messages");
  messagesDiv.innerHTML = "";
  snapshot.forEach(doc => {
    const m = doc.data();
    messagesDiv.innerHTML += `<p><b>${m.uid}:</b> ${m.text}</p>`;
  });
});

// Video Call (WebRTC stub)
function startCall() {
  alert("Video call feature will use WebRTC + Firebase signaling in full version.");
}
